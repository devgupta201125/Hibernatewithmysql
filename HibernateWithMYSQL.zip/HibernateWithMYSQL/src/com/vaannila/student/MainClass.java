package com.vaannila.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.vaannila.util.HibernateUtil;

import javax.swing.JOptionPane;

@WebServlet("/MainClass")
public class MainClass extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		
		long uid = Long.parseLong(request.getParameter("uid"));
		String name = request.getParameter("uname");
		String street = request.getParameter("street");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String zipcode = request.getParameter("zipcode");
		
		try {
			transaction = session.beginTransaction();
			
			Address address = new Address(street, city, state, zipcode);
			Student student = new Student(uid, name, address);
			
			session.save(student);
			
			JOptionPane.showMessageDialog(null, "servlet1");
			
			transaction.commit();
			
			JOptionPane.showMessageDialog(null, "servlet2");

		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}
